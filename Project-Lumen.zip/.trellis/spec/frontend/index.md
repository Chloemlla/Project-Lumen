# Frontend Development Guidelines

> Conventions for frontend development (Vite + React + TypeScript). Read before writing any frontend code.

---

## Stack (✅ decided, doc 05 §2 / D13)

**Vite + React + TS** · **Tailwind + shadcn/ui + Radix** · **TanStack Query** (server state) + **Zustand** (UI state) · WebSocket client (activity stream) · shared types/Zod from **`packages/shared`**.

## Pre-Development Checklist

Before writing frontend code, confirm:

- [ ] Cross-cutting types come from `packages/shared` (not redeclared locally).
- [ ] Server data goes through TanStack Query; live data through the WS hook — not duplicated into local state.
- [ ] New shared component/hook is justified (a second consumer exists), else keep it feature-local.
- [ ] Network/WS data is validated (Zod) before being treated as typed.
- [ ] No secret/token touches client storage or logs.
- [ ] Android native library changes follow [`android-native-libraries.md`](./android-native-libraries.md).
- [ ] Android haptic playback changes follow [`android-haptics.md`](./android-haptics.md).
- [ ] Android Baseline Profile changes follow [`android-baseline-profiles.md`](./android-baseline-profiles.md).
- [ ] Android Shizuku app network controls follow [`android-shizuku-network-controls.md`](./android-shizuku-network-controls.md).
- [ ] Android launcher shortcut changes follow [`android-launcher-shortcuts.md`](./android-launcher-shortcuts.md).
- [ ] Remotion Android product animation changes follow [`directory-structure.md`](./directory-structure.md) §2.2; build/render commands stay in GitHub Actions.
- [ ] VitePress docs changes follow [`docs-site.md`](./docs-site.md); build/test commands stay in GitHub Actions.
- [ ] Android Compose surface/top-bar chrome changes follow [`android-compose-surfaces.md`](./android-compose-surfaces.md).
- [ ] Android first-run gates / per-build update notes follow [`android-first-run-and-update-notes.md`](./android-first-run-and-update-notes.md).
- [ ] Android main-backend calls and backend-dependent UI follow [`android-backend-connectivity.md`](./android-backend-connectivity.md).

## Quality Check

Before marking work done (see [`quality-guidelines.md`](./quality-guidelines.md)):

- [ ] Lint + type-check green; strict TS, no `any`/unsafe casts.
- [ ] Scanned for the 7 code smells; none introduced.
- [ ] Tests pass (Vitest + RTL where applicable).

---

## Guidelines Index

| Guide | Description | Status |
|-------|-------------|--------|
| [Directory Structure](./directory-structure.md) | Feature-based layout, naming | ✅ Filled |
| [Component Guidelines](./component-guidelines.md) | shadcn/Radix + Tailwind, props, a11y, real-time surfaces | ✅ Filled |
| [Hook Guidelines](./hook-guidelines.md) | TanStack Query, WS activity-stream hook | ✅ Filled |
| [State Management](./state-management.md) | Server vs live vs UI state | ✅ Filled |
| [Type Safety](./type-safety.md) | Shared types, Zod validation, forbidden casts | ✅ Filled |
| [Android Native Libraries](./android-native-libraries.md) | NDK/CMake version ownership and 16 KB native library alignment | ✅ Filled |
| [Android Haptics](./android-haptics.md) | Vendor HE waveform generation and HapticPlayer hestub bridge | ✅ Filled |
| [Android Baseline Profiles](./android-baseline-profiles.md) | Baseline Profile generator module, ProfileInstaller, and workflow-only generation | ✅ Filled |
| [Android Shizuku Network Controls](./android-shizuku-network-controls.md) | Developer-only Shizuku app network policy management | ✅ Filled |
| [Android Foreground Services](./android-foreground-services.md) | Android client foreground service startup validation and permission gates | ✅ Filled |
| [Android Launcher Shortcuts](./android-launcher-shortcuts.md) | Android long-press app icon shortcut contracts | ✅ Filled |
| [Android Compose Surfaces](./android-compose-surfaces.md) | Soft Material surfaces, preference rows, dock vs secondary top-bar hierarchy | ✅ Filled |
| [Android First-Run and Update Notes](./android-first-run-and-update-notes.md) | OSS notice, immersive tutorial, per-build notes by commit+build time | ✅ Filled |
| [Android Backend Connectivity](./android-backend-connectivity.md) | Main-backend health state, capability gate, UI/background suppression, and recovery exclusions | ✅ Filled |
| [Quality Guidelines](./quality-guidelines.md) | Forbidden/required patterns, 7 smells, tests | ✅ Filled (⏳ test setup to confirm) |
| [VitePress Docs Site](./docs-site.md) | Docs package, Pages base path, workflow-only build | ✅ Filled |

> ⏳ items are recommendations from `docs/design/05-tech-stack-and-conventions.md` to finalize before the relevant code lands.

---

**Language**: all documentation and code identifiers are in **English** (project language policy; conversational replies may be Chinese).
