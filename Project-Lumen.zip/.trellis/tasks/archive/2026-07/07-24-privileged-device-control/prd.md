# PRD: Privileged Silent Vision + Enforced Lifecycle Lock

## Goal
Fully land backend docking for:
1. Privileged analyzer vision stream (policy-driven, consent-gated, exclusive camera policy optional)
2. Lifecycle event reporting (policy-driven telemetry; user-setting-driven keepalive only)

## Scope
- Backend: models, routes, MongoDB store, config-sync policies/feature flags, admin actions + dashboard modules
- Android: API client, policy application, vision session/heartbeat/frame upload, lifecycle event reporting

## Non-goals (explicitly forbidden)
- 无用户可知晓的静默摄像头调用 / 隐藏预览采集链路（必须：运行时 CAMERA 权限 + 应用内近距/眨眼功能开关作为同意门控）
- 拦截卸载、阻止强制停止、对抗系统清理的“卡死常驻”方案
- Device Owner / 多进程互拉 / 伪装组件等用于对抗用户控制的实现细节
- Local Gradle/Cargo builds (CI only)
- Root/Xposed/malware-grade uninstall interception

## Acceptance
- Authenticated clients can fetch merged device-control policy
- Vision sessions/heartbeats/frames accepted only when policy enabled and consent present
- Lifecycle events accepted and queryable in admin snapshot
- Admin can push silent-vision and lifecycle-lock policies (defaults: disabled / opt-in)
- Config sync ships `privileged_silent_vision` and `enforced_lifecycle_lock` (default disabled)
- Android applies policies only with local feature opt-in; reports lifecycle events when signed in
- Keepalive remains controlled solely by in-app `keepAliveEnabled` user setting
