# Android Baseline Profiles

## Goal

Apply the Android Baseline Profiles guidance from the referenced Google codelab to Project Lumen so release builds can include a startup/profile journey for faster first-run and warm startup behavior.

## Requirements

* Add the AndroidX Baseline Profile Gradle plugin to the app.
* Add a dedicated generator module instead of mixing profile generation with app instrumentation tests.
* Generate a profile for the release startup path and a short home-screen interaction.
* Keep build/test execution in GitHub Actions, not on the local machine.
* Leave unrelated dirty files out of the work commit.

## Acceptance Criteria

* [ ] Gradle includes a `:baselineprofile` module and app `baselineProfile` dependency.
* [ ] The app depends on ProfileInstaller for device-side profile installation support.
* [ ] A BaselineProfileRule test launches Project Lumen and records common startup/home interactions.
* [ ] GitHub Actions can run profile generation before release assembly.
* [ ] Existing local policy is honored: no local Gradle build/test commands are run.

## Definition of Done

* Code and workflow changes are committed and pushed.
* Local verification is limited to static inspection and git diff/status.
* CI/workflow verification is left to GitHub Actions.

## Technical Approach

Use `androidx.baselineprofile` version `1.4.1`, matching stable `androidx.benchmark:benchmark-macro-junit4:1.4.1` and `androidx.profileinstaller:profileinstaller:1.4.1`. Configure the app as the consumer and a `com.android.test` module as the producer. Use a Gradle Managed Device in CI so actual generation happens remotely.

## Out of Scope

* Local generation or local benchmark execution.
* Full performance benchmark dashboards.
* Product navigation changes beyond a deterministic startup/home traversal.

## Technical Notes

* Referenced codelab: `https://codelabs.developers.google.com/android-baseline-profiles-improve?hl=zh-cn#1`.
* Existing app module: `app`, namespace `com.projectlumen.app`, application id `com.chloemlla.projectlumen`.
* Existing build workflow already performs Android build, unit tests, and lint in GitHub Actions.
* Existing unrelated dirty file before implementation: `.gitignore`.
