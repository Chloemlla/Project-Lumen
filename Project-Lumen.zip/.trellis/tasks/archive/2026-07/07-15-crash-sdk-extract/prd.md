# Extract crash collection + adaptive crash UI into reusable SDK

## Goal

把现有崩溃收集、本地持久化、面包屑与崩溃展示页面抽成可复用的一体 Android Library SDK；崩溃展示页使用 WindowSizeClass 断点自适应；业务文案可配置注入，但强制不可移除 ChloeMlla 作者标识与 GitHub 链接，并采用最严格作者信息保护（fail-closed）。

## What I already know

* 现有实现：
  * `core/crash/CrashReport.kt` / `CrashReportStore.kt` / `CrashBreadcrumbs.kt`
  * `ProjectLumenCrashReportScreen.kt`
  * `ProjectLumenApplication.installCrashReporter()` + `recordCrash()`
  * `MainActivity` 启动门控：有报告时只渲染崩溃页
* 展示页当前仅 `widthIn(max=720.dp)` + 固定 stack 高度
* 工程仅有 `:app` / `:baselineprofile`
* 上传属 app 业务（`EyeCareTelemetryReporter`）
* 已有 `AppIntegrityGuard` 可参考 fail-closed 风格

## Decision (ADR-lite)

### 1) SDK module shape
* **Decision**: 一体 library（收集 + Compose UI）
* **Consequences**: 接入简单；带 Compose 依赖

### 2) Branding + author protection
* **Decision**:
  * 宿主可注入 app 名、版本/commit、分享主题等业务元数据/文案
  * **不可覆盖**：`ChloeMlla` + `https://github.com/Chloemlla/`
  * 报告 JSON / 剪贴板 / 分享文本 / UI 页脚强制含作者块
  * 启动 init + 打开崩溃页 + 导出前做作者指纹校验；失败 fail-closed
  * 多点冗余（常量、报告字段、UI、完整性哈希）
* **Consequences**: 开源无法绝对防 fork，但提高误删/反射改写成本

### 3) Adaptive layout
* **Decision**: WindowSizeClass 断点（Compact / Medium / Expanded）
* **How**:
  * Compact：单列；操作按钮纵向；内容全宽
  * Medium：居中限宽；操作可两列/横排
  * Expanded：更大 max content width；系统信息 pills 更疏；stack 区更高
  * 矮屏：压缩 stack `heightIn`、优先保证主操作可见
* **Consequences**: 依赖 `material3-window-size-class`（或等效 window size API）

### 4) Recommended defaults (unless you object)
* **Module**: `:lumen-crash`
* **Package**: `com.chloemlla.lumen.crash`
* **File share**: SDK 接受宿主提供的 `fileProviderAuthority`；未提供则仅允许分享纯文本
* **Upload**: 不在 SDK 内；`onCrashSaved` / `CrashUploadHook` 回调给 app
* **Docs**: 模块级 README（接入步骤 + 作者保护说明），不做独立 sample app（MVP）

## Requirements

1. 新建一体 Android Library 模块，迁入崩溃收集/存储/面包屑/Compose 展示页
2. 公开初始化 API（示例语义）：
   * `LumenCrash.install(application, config)`
   * `LumenCrash.record(throwable)` / breadcrumbs API
   * `LumenCrash.loadPendingReport()` / `clearPendingReport()`
   * Compose：`LumenCrashReportScreen(report, onContinue, ...)` 或 `LumenCrashGate { AppContent }`
3. `LumenCrashConfig` 支持业务元数据与文案覆盖；**不提供**作者覆盖项
4. 强制作者信息保护（最严格策略，见 Decision #2）
5. 崩溃页 WindowSizeClass 自适应
6. `:app` 迁移到 SDK：Application / MainActivity / ViewModel / Telemetry 适配
7. 删除 app 内旧 `core/crash` 与旧 CrashReportScreen 实现（或薄转发后删除）
8. EN/ZH 默认业务文案内置；Project Lumen 可覆盖为产品文案
9. 分享：复制、分享文本、（可选）分享文件

## Acceptance Criteria

* [ ] `:lumen-crash` 模块可被 `:app` 依赖
* [ ] 宿主 3 处以内调用可完成 install + 启动门控展示
* [ ] Compact/Medium/Expanded 下主操作可达、内容不裁切
* [ ] 任意导出载体含 ChloeMlla + https://github.com/Chloemlla/
* [ ] 篡改作者常量/指纹后 init 或展示 fail-closed
* [ ] 业务文案/版本信息可由宿主注入
* [ ] app 原有崩溃落盘、启动展示、复制/分享/清除继续行为不回退
* [ ] 上传仍由 app hook 触发

## Definition of Done

* Unit tests for report model / author integrity / store JSON round-trip（可测部分）
* Lint / typecheck / CI 由 GitHub workflow 验证（本地不跑全量构建）
* 模块 README 接入说明
* 提交并推送（按 AGENTS.md）

## Out of Scope

* 服务端 crash 后台
* 非 Android
* Crashlytics 替换
* core/ui 双 artifact
* 独立 sample app
* 绝对防 fork 删源码

## Technical Approach

1. 新建 `lumen-crash` Android library + Compose + Material3 + window-size-class
2. 迁移/重构：
   * `CrashReport` 去掉对 app `BuildConfig` 的硬依赖 → `CrashAppInfo` 注入
   * Store / Breadcrumbs 保留多路径原子写与脱敏
   * `CrashReporter` 封装 uncaught handler 与 `previousHandler` 链式调用
   * UI 抽到 SDK，WindowSizeClass 布局
3. `AuthorIntegrity`：内置常量 + SHA-256 指纹 + 运行时校验
4. app 侧：Application install；MainActivity gate；Telemetry 继续用 SDK 的 `CrashReport` 类型
5. 字符串资源迁到 library；app 用 config 覆盖产品文案

## Implementation Plan (small PRs / commits)

* PR1: scaffold `:lumen-crash` + author integrity + core models/store/breadcrumbs
* PR2: adaptive CrashReportScreen + public API
* PR3: migrate `:app` + remove old crash code + README

## Open Questions

* (none blocking)

## Technical Notes

* 作者常量：`ChloeMlla` / `https://github.com/Chloemlla/`
* 参考 `AppIntegrityGuard` fail-closed
* 当前 crash 字符串在 `values/strings.xml` 与 `values-zh/strings.xml` 的 `crash_report_*`
