# Vivo doc 509 Android 12 adaptation

## Goal
Adapt Project Lumen against vivo Android 12 guidance (doc 509) using the shared fetch/compare workflow.

## Done
- Fetched package docs/vivo-adaptation/509-android-12
- Confirmed background FGS start guards, immutable PendingIntents, explicit exported attributes, FGS immediate notifications, interactive overlays, no custom RemoteViews / CLOSE_SYSTEM_DIALOGS / nested-intent launch
- Hardened DeveloperDebugOverlayService start/simulate paths with runCatching + crash recording
- Added docs/ANDROID_12_VIVO_ADAPTATION.md and linked it from the workflow doc
