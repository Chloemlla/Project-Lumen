# Vivo doc 797 + 832 adaptation refresh

## Goal
Adapt Project Lumen against vivo docs 797 (Android 15 Beta3) and 832 (Android 16) using the shared fetch/compare workflow.

## Done
- Fetched packages for 797 and 832
- Implemented/confirmed Android 15 force-stop recovery, edge-to-edge bars, low-light camera boost
- Confirmed Android 16 predictive back / adaptive layout / intent matching already present
- Updated ANDROID_15 / ANDROID_16 notes and workflow index
