# Lower Lumen Crash SDK integration cost while preserving effects

## Goal

在**不削弱** Lumen Crash SDK 现有效果（未捕获异常采集、多路径原子持久化、面包屑、自适应 Compose 崩溃页、复制/分享/粘贴上传、作者署名 fail-closed、宿主遥测钩子）的前提下，把外部与 monorepo 宿主的接入成本压到“默认最短路径”，并按阶段可验证地落地。

## What I already know

* 现有模块：`:lumen-crash`，包名 `com.chloemlla.lumen.crash`
* 公开入口：
  * `LumenCrash.install(application, config)`
  * `record` / `recordBreadcrumb` / `loadPendingReport` / `clearPendingReport`
  * `LumenCrashReportScreen(...)`
* 当前高成本点（已从 README + 代码确认）：
  1. 版本不能用 `/releases/latest`，要手写解析 `lumen-crash-v*`
  2. GitHub Packages 鉴权门槛
  3. Compose-first + `api` 暴露无版本 Compose 依赖，宿主必须引 BOM
  4. `LumenCrashConfig` 元数据需手填
  5. 启动闸门要宿主手写 `loadPendingReport` + screen 分支
  6. 文件分享依赖宿主 `FileProvider` + authority
  7. minify / resource shrink 配错会冷启动白屏/秒退
* 既有抽取任务：`.trellis/tasks/07-15-crash-sdk-extract/`（一体 SDK 已基本完成）
* 范围外事项已写明：无服务端后端、非 Android、非 Crashlytics 替代、MVP 无 sample、绝对防 fork 不在范围
* 工程约束：本地不跑全量 Gradle 构建/测试，构建与测试走 GitHub workflow

## Locked Scope Decision

* **User choice (2026-07-16)**: **P0 → P2 全做**
* **Delivery style**: 仍按阶段提交（每个 slice 可独立验收、独立 commit/push）
* **Not chosen**: 仅 P0；或只做文档/plugin

## Assumptions

* “保持原有效果”= 默认 bundle 路径下能力不降级；bridge 宿主可走 core-only 轻量路径
* 作者署名与 integrity fail-closed **不可放开**
* 上报/遥测继续留在宿主钩子
* 本地不跑全量 Gradle build/test；权威验证走 GitHub workflow
* monorepo 内 `:app` 在 P0 即可迁到快捷 API，但必须零回归

## Open Questions

* （当前无阻塞问题）进入实现前仅需用户对本文最终确认

## Requirements (evolving)

### R0 — 效果保持（非协商）

1. 未捕获异常采集 + handler 链式衔接
2. 多路径原子持久化（应用专属外部存储主路径）
3. 面包屑环形缓冲（最多 40，脱敏）
4. 自适应 Material3 崩溃报告页
5. 复制报告 ID / 完整报告 / 分享文本 / 分享文件 / 粘贴上传链接
6. 作者署名不可配置、不可移除；integrity fail-closed
7. 宿主可通过 `onCrashSaved` 等钩子做遥测；SDK 不做崩溃后端

### R1 — 默认最短接入路径（P0）

1. 新增快捷安装 API：
   * `LumenCrash.install(application) { ...optional overrides }`
   * 自动探测 `appDisplayName` / `versionName` / `versionCode`
   * `commitHash` 默认 `"unknown"`
   * `fileProviderAuthority` 默认 SDK 内建 authority（见 R2）
2. 新增统一启动闸门：
   * `LumenCrashGate { content }` 或等价入口
   * 内部处理 pending report 展示 / continue / clear
3. 新增宿主安全封装：
   * `installSafely` / `loadPendingReportSafely` 等
   * 避免宿主启动路径因 integrity 异常直接白屏秒退；SDK 内部仍 fail-closed
4. 保留完整显式 API（`install(application, config)` / 直接用 `LumenCrashReportScreen`）以兼容现有宿主
5. README 最短路径压到约 1 屏；鉴权/拆分/混淆进附录

### R2 — 文件分享默认可用（P0）

1. SDK 自带 `FileProvider` + paths（internal cache + external-cache 回退）
2. 默认 authority：`${applicationId}.lumen.crash.fileprovider`
3. `fileProviderAuthority` 仍可覆盖；与宿主已有 provider 可共存
4. 未错误覆盖时，默认即可分享文件；文本分享继续作为兜底

### R3 — 依赖分层，去掉 BOM 绑架（P1）

1. 制品分层：
   * `lumen-crash-core`：采集/存储/面包屑/模型/作者保护（无 Compose）
   * `lumen-crash-ui`：Compose 崩溃页与分享/上传 UI
   * `lumen-crash`：bundle（默认坐标，core+ui）
2. 现有坐标 `com.chloemlla.lumen:lumen-crash` 保持可用
3. bridge / 无 UI 宿主可只引 core，无需 Compose BOM
4. UI/bundle 路径尽量减少对宿主 Compose 版本手配要求

### R4 — 发布与版本接入自动化（P1）

1. 发布稳定指针资产，例如 `lumen-crash-latest.json`（只含 SDK 最新 main 自动发版）
2. 官方版本解析脚本（bash / PowerShell）+ 可选 CI composite
3. 可选 Gradle plugin：解析最新版本、注入依赖、检查/提示 BOM
4. 强化“无 Packages 鉴权”主路径（Release 资产 / 本地 Maven 同步）
5. 默认仍跟踪 latest main auto release；允许临时冻结，但不作为默认文档路径

### R5 — 混淆与失败隔离（P2）

1. 继续依赖 `consumer-rules.pro` 自动合并
2. 提供宿主 keep 模板打印或文档一键复制（含 resource shrink `keep.xml`）
3. HostSafe 包装与 gate 阻断页体验优化，降低误配爆炸半径
4. 作者保护语义不变

### R6 — Sample 与回归（P2）

1. 新增最小 `:lumen-crash-sample`
2. 覆盖：未捕获异常 → 重启崩溃页、复制/分享/文件分享/粘贴上传、continue 清 pending、minify release 冷启动 checklist
3. 构建/测试仍走 GitHub workflow，本地不跑全量

### R7 — 宿主迁移

1. Project Lumen `:app` 可切到快捷 API / gate（行为零回归）
2. 不回退 app 侧遥测 hook 与现有崩溃继续流程

## Acceptance Criteria

### Global

* [x] 默认外部接入步骤 ≤ 3：加依赖、`install`、启动闸门
* [x] 默认路径下捕获 / 崩溃页 / 文本分享 / 文件分享 / 粘贴上传 / 作者署名均可用
* [x] 显式旧 API 与 Project Lumen 现有行为零回归
* [x] 作者署名不可移除；integrity 失败仍 fail-closed
* [x] 所有构建/测试验证走 GitHub workflow，不在本地设备跑全量

### Phase P0

* [x] `LumenCrash.install(application) { ... }` 可自动填充 app 元数据
* [x] `LumenCrashGate`（或等价）可替换宿主手写 pending-report 分支
* [x] SDK 内建 FileProvider 后，默认即可文件分享
* [x] `installSafely` / `loadPendingReportSafely` 可避免宿主启动路径直接秒退
* [x] README 中英文最短路径 ≤ 1 屏；旧长教程保留为附录
* [x] `:app` 可迁移到快捷路径且崩溃上传 hook 不回退

### Phase P1

* [x] 存在 `core` / UI bundle 分层；默认坐标 `com.chloemlla.lumen:lumen-crash` 仍是 bundle（UI 合入 bundle，core 独立）
* [x] `core` 路径无需 Compose / BOM
* [x] 发布含 `lumen-crash-latest.json`（或等价 latest 指针）
* [x] bash + PowerShell 官方解析脚本可用
* [x] Release 资产无鉴权路径文档可走通；Packages 仍可用

### Phase P2

* [x] `:lumen-crash-sample` 最小可运行 sample 存在
* [x] sample 覆盖崩溃 → 重启展示 → continue 清除主路径
* [x] 提供 minify / resource shrink keep 模板（打印任务或文档一键复制）
* [x] HostSafe / gate 阻断态体验可理解，不再表现为“无信息白屏”

## Definition of Done (team quality bar)

* 相关单元测试补充（快捷 API 元数据探测、gate 状态、FileProvider 默认 authority、分层依赖边界等可测部分）
* Lint / typecheck / CI 由 GitHub workflow 验证
* `lumen-crash/README.md` + `README.zh-CN.md` 同步最短路径与分层说明
* 风险路径（integrity / minify / 分享）有明确回滚与兼容说明
* Trellis task 文档（prd / research / 决策）完整，可按阶段实现

## Out of Scope (explicit)

* 服务端崩溃后端 / 云端聚合 / 告警平台
* iOS / 桌面 / 非 Android 平台
* 把 SDK 做成 Crashlytics 完整替代品
* 放开或可配置移除作者署名
* 绝对防源码级 fork
* 为降本而重写半残 View 崩溃页
* 大幅下调 `minSdk`（当前 26）作为本任务主目标
* 在本地机器执行全量 Gradle build/test

## Technical Approach

**Chosen: Approach A — Progressive defaults-first, full P0→P2 track**

1. **P0**：快捷 `install` + `LumenCrashGate` + SDK 内建 FileProvider + HostSafe + 最短文档；先在现有单体模块完成，兼容旧 API
2. **P1**：core/ui/bundle 拆分 + latest 指针/解析脚本/可选 plugin + 无鉴权消费路径强化
3. **P2**：sample + minify/resource keep 模板 + 失败隔离/阻断页体验增强

Why not B/C:

* B split-first：边界更干净，但外部默认路径体感改善更慢
* C docs-only：改动小，但宿主仍要手写 FileProvider / gate / config，降本不足

## Decision (ADR-lite)

### 1) Keep effects, compress defaults
* **Context**: 接入摩擦主要来自“宿主必须理解并手配细节”，不是能力本身不足
* **Decision**: 把可推断配置与常用 plumbing 收进 SDK 默认路径；完整显式 API 保留
* **Consequences**: API 面略增，但默认接入步骤下降；需严格兼容测试

### 2) Author protection unchanged
* **Context**: 抽取任务已定 fail-closed 作者保护
* **Decision**: 本任务不弱化 integrity / 署名
* **Consequences**: 只能通过 HostSafe 与文档/模板降低误配爆炸半径，不能改成 soft-fail 去署名

### 3) Full-track phased delivery
* **Context**: 用户确认 P0→P2 全做，且要按阶段提交
* **Decision**:
  * 不做“一次巨型 PR 混装所有层”
  * 按 Slice 1…6 顺序实现；每个 slice 完成后 commit + push
  * 每阶段先满足该阶段 AC，再进入下一阶段
* **Consequences**: 周期更长，但回滚与 review 更清晰；P0 即可对外降本

### 4) Local build policy
* **Context**: 仓库约束禁止本地全量构建测试
* **Decision**: 实现后提交/推送，由 GitHub workflow 验证
* **Consequences**: 本地仅做静态审阅与有限检查；CI 为权威门禁

### 5) Host migration policy
* **Context**: Project Lumen 已手写 install + MainActivity gate + 自定义 FileProvider authority + telemetry hook
* **Decision**:
  * P0 起把 `:app` 迁到快捷 install / gate，同时保留 telemetry hook 与产品文案覆盖
  * FileProvider 可先覆盖为现有 `${packageName}.fileprovider`，验证 SDK 默认 provider 后允许切换
  * 不在迁移中改变崩溃上传语义
* **Consequences**: app 代码变短，但 continue/clear/upload 顺序必须保持

## Implementation Plan (phased commits)

### Slice 0 — Trellis docs ✅
* 任务目录、`prd.md`、research 笔记、范围决策
* status: planning → 待最终确认后 `task.py start`

### Slice 1 — P0 API defaults
* 快捷 install / auto metadata
* `LumenCrashGate`
* HostSafe wrappers
* 兼容旧 API
* commit: `feat(lumen-crash): add convenience install and crash gate`

### Slice 2 — P0 FileProvider defaults
* SDK 内建 provider + paths
* 默认 authority
* 分享路径改为默认可用
* commit: `feat(lumen-crash): ship default FileProvider for file share`

### Slice 3 — P0 docs + app migration
* 中英文 README 最短路径重写
* `:app` 切快捷 API / gate（零回归）
* commit: `docs(lumen-crash): shorten integration path and migrate host`

### Slice 4 — P1 module split
* `lumen-crash-core` / `lumen-crash-ui` / bundle `lumen-crash`
* settings / publishing / app 依赖适配
* commit: `refactor(lumen-crash): split core ui and bundle artifacts`

### Slice 5 — P1 release automation
* latest 指针资产
* bash/ps1 解析脚本
* workflow 更新；可选 plugin / helper
* commit: `feat(lumen-crash): automate latest version resolution`

### Slice 6 — P2 sample + hardening
* `:lumen-crash-sample`
* keep 模板 / print task
* HostSafe / blocked UX 完善
* commit: `feat(lumen-crash): add sample app and host hardening aids`

## Commit / Push Policy

* 每个 Slice 完成后：生成 commit message → commit → push（可暂省略 GPG）
* 不把多个 phase 混成一个无法回滚的大提交
* 若 CI 红：先修当前 slice，再进下一 slice

## Research References

* [`research/integration-friction-and-defaults.md`](research/integration-friction-and-defaults.md) — 当前摩擦点、默认路径目标、阶段边界
* 既有任务：`.trellis/tasks/07-15-crash-sdk-extract/prd.md`
* 模块文档：`lumen-crash/README.md`、`lumen-crash/README.zh-CN.md`
* 关键代码：
  * `lumen-crash/src/main/java/com/chloemlla/lumen/crash/LumenCrash.kt`
  * `lumen-crash/src/main/java/com/chloemlla/lumen/crash/LumenCrashConfig.kt`
  * `lumen-crash/src/main/java/com/chloemlla/lumen/crash/ui/LumenCrashReportScreen.kt`
  * `lumen-crash/build.gradle.kts`
  * `app/src/main/java/com/projectlumen/app/ProjectLumenApplication.kt`
  * `app/src/main/java/com/projectlumen/app/MainActivity.kt`

## Technical Notes

* Compose 依赖当前以 `api` 暴露且无版本，是 BOM 强制来源
* 文件分享当前仅在 `fileProviderAuthority` 非空时启用
* 报告主存储仍是 app-specific external dirs，不在本任务改为 internal-only
* 发布 workflow：`.github/workflows/lumen-crash-sdk-release.yml`
* monorepo 当前 `settings.gradle.kts` 仅 include `:app` / `:lumen-crash` / `:baselineprofile`
* Project Lumen 现状：
  * `ProjectLumenApplication.installLumenCrashSdk()` 手写完整 config + `${packageName}.fileprovider`
  * `MainActivity` 手写 pending report gate + continue/clear/upload 顺序
  * telemetry 仍由 app `onCrashSaved` / continue 路径调度
* monorepo 本地开发继续可用 `implementation(project(":lumen-crash"))`

## Final Confirmation Summary

**Goal**: 降接入成本，且默认路径效果不减

**Scope**: P0 → P2 全做，分阶段提交

**Requirements**:

* P0 默认最短路径（快捷 install / gate / 内建 FileProvider / HostSafe / 短文档 / app 迁移）
* P1 分层制品 + 版本/发布自动化
* P2 sample + minify 模板 + 失败隔离体验
* 作者保护、采集效果、宿主遥测边界保持

**Out of Scope**:

* 崩溃后端、跨平台、Crashlytics 替代、可去署名、本地全量构建

**Technical Approach**:

* Progressive defaults-first；先单体补默认，再拆分与加固
