# Integration Friction and Defaults Plan

## Source inspection

Inspected:

- `lumen-crash/README.md`
- `lumen-crash/README.zh-CN.md`
- `lumen-crash/build.gradle.kts`
- `lumen-crash/src/main/java/com/chloemlla/lumen/crash/LumenCrash.kt`
- `lumen-crash/src/main/java/com/chloemlla/lumen/crash/LumenCrashConfig.kt`
- `lumen-crash/src/main/java/com/chloemlla/lumen/crash/ui/LumenCrashReportScreen.kt`
- `lumen-crash/consumer-rules.pro`
- `app/src/main/java/com/projectlumen/app/ProjectLumenApplication.kt`
- `app/src/main/java/com/projectlumen/app/MainActivity.kt`
- `.trellis/tasks/07-15-crash-sdk-extract/prd.md`

## Current friction map

| Friction | Why it costs | Effect risk if removed naively |
|---|---|---|
| Manual version resolve (`lumen-crash-v*`) | external hosts need scripts; `/releases/latest` is unsafe | wrong package / mixed non-SDK releases |
| GitHub Packages auth | PAT / SSO / secrets setup | private package access failures |
| Compose BOM required | Compose deps published as unversioned `api` | empty-version resolution failures |
| Hand-written config metadata | every host fills version/name/code | missing metadata quality only |
| Hand-written startup gate | load + branch + clear easy to miss | pending report loop or no crash UI |
| Host FileProvider required for file share | authority + paths XML | file share unavailable (text still works) |
| Minify/resource shrink keep rules | release white-screen / kill | integrity/API stripped |

## Effects that must remain

1. Uncaught exception capture with handler chaining
2. Multi-path atomic persistence on app-specific external storage
3. Breadcrumbs ring buffer (40, redacted)
4. Adaptive Compose crash UI
5. Copy / share text / share file / paste upload
6. Forced author attribution + fail-closed integrity
7. Host-owned telemetry via hooks (`onCrashSaved` etc.)

## Defaults-first target path

```kotlin
// Application
LumenCrash.install(this) {
    // optional overrides only
}

// Root UI
LumenCrashGate {
    RealApp()
}
```

Default capabilities after that:

- capture works
- pending report gate works
- text share works
- file share works via SDK provider
- paste upload remains available
- author footer remains forced

## Recommended phasing

### P0 (highest ROI, lowest risk)

- Convenience install + auto metadata
- `LumenCrashGate`
- HostSafe wrappers
- SDK-owned FileProvider defaults
- README short path rewrite
- Keep monolith module for now

### P1

- `core` / `ui` / `bundle` split
- keep `com.chloemlla.lumen:lumen-crash` as bundle
- latest pointer asset + resolver scripts
- optional gradle plugin / no-auth release asset path emphasis

### P2

- sample app
- minify/resource keep templates
- richer blocked-state UX around integrity failures

## Non-goals for cost reduction

- Do not weaken author protection
- Do not add crash backend into SDK
- Do not rewrite UI into incomplete View system just for host simplicity
- Do not treat minSdk reduction as this task's main goal
- Do not run full local Gradle build/test; CI is the gate

## Compatibility constraints

- Existing explicit `install(application, config)` must keep working
- Project Lumen host may migrate gradually to convenience APIs
- External coordinate `com.chloemlla.lumen:lumen-crash` remains default
- Consumer proguard auto-merge remains required baseline

## Validation strategy

Because local full builds are prohibited:

1. Static review of public API / manifest merge / docs
2. Unit tests for pure logic where cheap
3. Commit + push; rely on GitHub workflows for assemble/test
4. Phase acceptance checklist in PRD

## Locked decision for MVP coding slice

User selected **option 3** on 2026-07-16:

- Full **P0 → P2** track
- Still **phased commits** (no single mega-commit)
- Continue after Trellis docs are finalized

Implications:

1. Do not stop after convenience API/docs
2. Module split, latest pointer, sample, and hardening are in scope
3. Each slice must remain independently reviewable and pushable
4. Preserve author protection and current crash effects throughout
