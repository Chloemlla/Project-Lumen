# First-run open source notice and third-party credits

## Goal

On first install/open, show a full-screen notice page that states the official open-source repository, that Project Lumen is permanently free (beware of paid/scam redistributions), the project license, and credits for third-party dependencies (name, author, description, license). Provide EN + ZH copy and a way to reopen from About.

## Decisions (locked — all recommended)

* Presentation: one full-screen scrollable notice page (not multi-page pager, not dialog-only)
* Gate: first install / first open, before the existing product onboarding when both are pending
* Completion: Continue marks OSS notice completed; does not auto-show again
* Reopen: About page entry reopens the same notice
* Credits: curated static list of direct app dependencies with name / author / description / license / optional URL
* i18n: English (`values`) + Chinese (`values-zh`)
* Project license display: Apache License, Version 2.0 (no root LICENSE file today; UI states the project license and links to the official repo for source)
* Official source URL: `https://github.com/Chloemlla/Project-Lumen`
* Do not replace product feature onboarding; OSS notice is a separate first-run gate

## Requirements

1. First-run full-screen OSS notice with:
   * Official open-source repository section + open/copy action
   * Permanently free / anti-scam warning
   * Project license section (Apache-2.0)
   * Third-party dependency credits list: name, author, description, license (tap opens homepage when URL exists)
2. Preference/secure flag so completed notice does not auto-reappear
3. About entry to reopen notice without re-arming first-run if already completed
4. EN + ZH strings for all new UI copy
5. Escape apostrophes and other string resource hazards correctly

## Acceptance Criteria

* [ ] Fresh install shows the OSS notice before product onboarding when both incomplete
* [ ] Notice includes official repo, free/anti-scam, project license, and dependency credits
* [ ] Each credit shows name, author, description, license
* [ ] Continue dismisses notice and does not auto-show again
* [ ] About can reopen the notice
* [ ] EN + ZH strings present
* [ ] Commit + push after implementation (no local Gradle)

## Technical Approach

* Add `ProjectLumenOpenSourceNoticeScreen` + credits data model
* Extend install/onboarding state (or a dedicated `ossNoticeCompletedAt` in `SecureCredentialStore`) to gate first-run
* Wire in `ProjectLumenApp` above existing onboarding
* About links card gains reopen entry
* Strings in `values/strings.xml` and `values-zh/strings.xml`

## Out of Scope

* Full SPDX dump of transitive dependency graph
* Replacing product onboarding content
* Local Gradle/Flutter builds
* Adding monetization / paid tiers related UI

## Technical Notes

* Existing onboarding: `ProjectLumenOnboardingScreen` / `ProjectLumenViewModel.refreshOnboardingState`
* About: `ProjectLumenAboutAndDialogs.kt`, `PROJECT_LUMEN_REPO_URL`
* Deps source: `app/build.gradle.kts` (+ `lumen-crash` module)
* Task: `.trellis/tasks/07-17-first-run-oss-notice-credits`
