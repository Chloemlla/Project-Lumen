# Default Disable Backend Client Verification

## Goal

Backend client-side verification gates should be disabled by default, including production deployment defaults, and should only be enabled when an operator explicitly sets the environment variable.

## What I Already Know

* The backend is a Rust/Axum service under `backend/`.
* There is no mTLS client certificate chain verification in backend code.
* The backend client verification flow currently present is HMAC request signing in `backend/src/routes/security.rs`.
* `backend/src/config.rs` reads `LUMEN_REQUIRE_REQUEST_SIGNING` with a default of `true`.
* `.github/workflows/build-artifacts.yml` hard-codes `LUMEN_REQUIRE_REQUEST_SIGNING: "true"` for deployment.
* Repository policy prohibits local build/test/lint execution; verification must be static locally and CI-driven after push.

## Requirements

* Change backend request-signing enforcement to default disabled when `LUMEN_REQUIRE_REQUEST_SIGNING` is absent.
* Keep manual opt-in support: `LUMEN_REQUIRE_REQUEST_SIGNING=true` must still enable request signature verification.
* Remove production/deployment hard-coded enablement so production also follows the explicit environment variable.
* Update backend documentation to state the default disabled behavior and the opt-in environment variable.
* Do not change Android certificate pinning behavior in this task.
* Do not change purchase verification fail-closed behavior in this task.

## Acceptance Criteria

* [ ] `Config::from_env()` defaults `require_request_signing` to `false`.
* [ ] GitHub deployment no longer forces request signing on without an operator-provided variable.
* [ ] Backend README documents `LUMEN_REQUIRE_REQUEST_SIGNING=false` as the default and explains setting it to `true` enables verification.
* [ ] Existing request-signing code path remains intact when enabled.
* [ ] No local build/test/lint command is run.

## Definition of Done

* Code and documentation are updated.
* Static review confirms the only default-enable paths are removed.
* Changes are committed and pushed so GitHub Actions can perform actual verification.

## Technical Approach

Use the existing `LUMEN_REQUIRE_REQUEST_SIGNING` switch. Change only its default and deployment wiring, instead of introducing a new environment variable or removing the middleware.

## Decision (ADR-lite)

**Context**: The backend currently enforces signed client requests by default, and deployment also hard-codes enforcement on.

**Decision**: Make `LUMEN_REQUIRE_REQUEST_SIGNING` an explicit opt-in flag everywhere. Missing or empty env keeps request signing disabled.

**Consequences**: Production no longer verifies signed client headers unless the environment explicitly sets `LUMEN_REQUIRE_REQUEST_SIGNING=true`. Operators can still re-enable the existing HMAC verification path without code changes.

## Out of Scope

* Android certificate pinning configuration.
* TLS/mTLS termination changes.
* Play Integrity implementation.
* Google Play purchase verification defaults.

## Technical Notes

* Relevant files: `backend/src/config.rs`, `backend/src/routes/security.rs`, `backend/src/server.rs`, `backend/README.md`, `.github/workflows/build-artifacts.yml`.
* The local machine must not run actual build, test, lint, install, or package commands.
