# Vivo doc 428 Android 11 adaptation

## Goal
Adapt Project Lumen against vivo Android 11 guidance (doc 428).

## Done
- Fetched package docs/vivo-adaptation/428-android-11
- Confirmed scoped storage via SAF, one-time camera permission gates, no location APIs, camera FGS type, QUERY_ALL_PACKAGES for Shizuku app list, no custom-view Toast.setView path
- Added historical process-exit reason breadcrumb on cold start
- Added docs/ANDROID_11_VIVO_ADAPTATION.md and linked it from the workflow doc
