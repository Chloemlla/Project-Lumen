# Existing Native Security Gap Analysis

## Current implementation

* `lumen_security.cpp` already embeds the request-signing secret, compares the package and optional release certificate, reads `TracerPid`, scans suspicious environment entries, and searches maps/cmdline/tasks/fds/Unix sockets for Frida/Xposed/Substrate/Riru/Zygisk artifacts.
* `AppIntegrityGuard` invokes the native verdict during release startup and adds Java debugger/runtime-hook signals.
* `ProjectLumenRequestSigner` currently calls `NativeSecurityBridge.requestSigningSecretOrNull()`, bringing the raw secret into Kotlin/Java memory before performing HMAC-SHA256.
* The native verdict is only a Boolean, so diagnostics cannot distinguish identity, certificate, debugger, environment, and hook-artifact failures.
* Release request signing fails when the library is unavailable, but it does not require a fresh native environment verdict inside the signing operation.

## Security gaps

1. The raw signing secret crosses JNI and is retained in a managed `String`/`ByteArray` path.
2. A startup-only Boolean verdict cannot express stable failure reasons or prove that a later request was signed after native policy validation.
3. Package/certificate strings are normalized only by the Kotlin producer; native comparison is case-sensitive and the certificate may be optional.
4. The current API does not bind the signing operation to the successful native identity/environment evaluation.

## Recommended approach

* Replace raw-secret JNI export with native `signCanonicalPayload` HMAC-SHA256; keep SHA/HMAC implementation in a small dedicated native helper so `lumen_security.cpp` remains orchestration rather than a super file.
* Return a bitmask verdict with stable reasons: package mismatch, process-name mismatch, certificate missing/mismatch, tracer, suspicious environment, hook artifact, and native internal failure.
* Store a process-local verified-identity state only after a zero-failure release evaluation. Native signing requires that state and re-runs runtime debugger/hook checks before returning a signature.
* Keep debug fallback signing for deliberate local development only. Release never receives or falls back to the raw secret.
* Keep checks side-effect free: no `ptrace`, abort, process kill, or destructive anti-analysis behavior.

## Compatibility

* Preserve the existing canonical payload and lowercase HMAC-SHA256 hex format, so the backend protocol does not change.
* Preserve current package and certificate build inputs while normalizing certificate case/separators in native code.
* `AppIntegrityGuard` remains the startup enforcement owner; request signing independently fails closed in release.
