# Harden Native Client Security Boundary

## Goal

Strengthen the Android client's native protection boundary so `lumen_security.cpp` owns the request-signing secret and performs package-name, signing-certificate, anti-debugging, and hook-artifact verification before protected remote requests can proceed.

## What I already know

* The user explicitly requires `lumen_security.cpp` to own native request-signing secrets, package/certificate validation, anti-debug checks, and hook-artifact detection.
* Project Lumen already has a native `lumen_security` bridge used by request signing and startup integrity checks.
* Release behavior must fail closed for protected remote operations when native protection is unavailable or invalid.
* All actual builds, lint, and tests must run in GitHub Actions; local work is limited to source inspection and static diff checks.
* Changes must stay split by responsibility and must not create or grow a super file.
* Existing native checks already cover the requested package/certificate, `TracerPid`, suspicious environment, process maps, task names, file descriptors, and common Frida/Xposed/Substrate/Riru/Zygisk artifacts.
* The main remaining weakness is that JNI currently returns the raw signing secret to Kotlin, which then performs HMAC in managed memory.
* The current native verdict is Boolean-only and is not cryptographically bound to each release request-signing operation.

## Assumptions

* Existing backend canonicalization and lowercase HMAC-SHA256 signature format remain compatible.
* Checks return structured reason flags to Kotlin rather than only a single boolean, while release request signing remains fail-closed.
* Anti-debug and hook detection are defensive signals, not claims of absolute tamper resistance.
* Debug builds retain the documented local fallback; release builds require native signing and a verified native environment.

## Requirements (evolving)

* Keep the signing secret and HMAC/signature material inside native code; do not expose the raw secret to Kotlin/Java.
* Verify the runtime application package and signing certificate against release expectations.
* Detect common debugger attachment and native/Java hook artifacts with bounded, non-crashing checks.
* Surface structured verification outcomes for diagnostics without logging secrets or sensitive raw evidence.
* Preserve existing backend request-signing compatibility and debug/development workflows where intentionally allowed.
* Bind release signing to a successful native identity/environment verdict and repeat volatile debugger/hook checks before returning each signature.
* Normalize certificate fingerprints and add a process-name/package consistency check.
* Keep native crypto and scanning helpers in small files; `lumen_security.cpp` owns orchestration and JNI policy without becoming a super file.

## Acceptance Criteria (evolving)

* [ ] Protected release requests cannot obtain a signature when package/certificate/native integrity verification fails.
* [ ] Kotlin/Java cannot retrieve the raw native request-signing secret.
* [ ] Package and signing-certificate mismatches have stable structured reason codes.
* [ ] Debugger and hook-artifact detections have stable structured reason codes and bounded false-positive handling.
* [ ] Existing valid release signing requests remain protocol-compatible with the backend.
* [ ] Regression tests cover pure policy/result mapping; GitHub Actions verifies Android/JNI compilation and tests.
* [ ] Startup diagnostics distinguish identity, certificate, debugger, environment, hook, native-load, and internal failures.

## Definition of Done (team quality bar)

* Unit/regression tests added for testable policy and bridge behavior.
* Android build, lint, native compilation, and tests pass in GitHub Actions.
* Native security contracts and limitations are documented in Trellis specs.
* Rollback preserves the current request-signing protocol if device-specific detection causes regressions.
* Changes are committed without GPG signing and pushed automatically.

## Out of Scope (explicit)

* Claiming protection against a fully controlled/rooted kernel or source-level fork.
* Changing backend authentication or entitlement semantics unrelated to native request signing.
* Shipping private keys or remotely recoverable secrets in Kotlin, resources, or logs.

## Technical Notes

* Likely files: `app/src/main/cpp/lumen_security.cpp`, JNI bridge declarations, `NativeSecurityBridge`, `AppIntegrityGuard`, request-signing interceptors, CMake/proguard configuration, and native security tests/workflow checks.
* Source inspection and repository-backed research will refine exact ABI, certificate source, reason-code model, and compatibility constraints.

## Research References

* [`research/existing-native-security-gap.md`](research/existing-native-security-gap.md) — current implementation, raw-secret JNI gap, structured-verdict design, and protocol-compatible native HMAC approach.

## Decision (ADR-lite)

**Context**: The existing bridge already detects common tampering, but it exports the complete signing secret to Kotlin and exposes only a startup Boolean verdict.

**Decision**: Move HMAC-SHA256 into native code, remove the raw-secret JNI method, introduce stable bitmask failure reasons, record a verified process identity only after a clean release evaluation, and require that state plus fresh volatile checks for every release signature. Keep debug fallback behavior and the backend canonical payload unchanged.

**Consequences**: Managed code never receives the secret and diagnostics become actionable. The compiled client secret remains extractable to a sufficiently privileged/source-level attacker, so documentation must describe this as cost-raising hardening rather than absolute secrecy.
