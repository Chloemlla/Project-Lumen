# Backend Capability and Gating Inventory

## Main Project Lumen backend consumers

* Account/session: email login, verification, refresh, `/me`, device registration.
* Commercial/cloud: entitlements, purchase verification, feature flags, config sync, cloud sync push/pull, cloud backup upload/restore.
* Diagnostics/telemetry: telemetry uploads, crash/report-related uploads, face analysis frames.
* Privileged device control: policy fetch, silent-vision sessions/heartbeats/frames, surface frames, lifecycle events.
* Release discovery: Project Lumen API release check.
* The translation client uses a separate remote base URL and is not a reliable proxy for main backend health.

## Existing seams

* `ProjectLumenApiClient.health()` is an unsigned public health probe and all main backend requests flow through one private `request` function.
* User-facing remote/account/cloud actions are orchestrated by `ProjectLumenRemoteFeatureEntry` and shown through the Settings remote cloud card.
* Background telemetry/device-control paths call the same shared `ProjectLumenApiClient`, so an execution-boundary gate can protect more than visible UI.
* Developer advanced UI already exposes API diagnostics and is the correct home for health/override controls.

## Recommended approach

* Add a single application-scoped `BackendConnectivityController` with actual health (`unknown/checking/reachable/unreachable`), persisted last-known result/time, and a separate persisted developer force-enable flag.
* Add a small `BackendCommunicationPolicy` pure resolver that yields effective availability without misreporting forced enable as health.
* Inject the policy into `ProjectLumenApiClient`; all calls except health probe are rejected locally while gated. This covers background and action paths even if a UI entry is missed.
* Settings consumes the same state and hides the remote/backend section while gated. The Developer page always remains visible and can refresh health or toggle forced enable.
* Retain the external GitHub releases link as an out-of-band recovery path. Gate the API-backed update check with other backend requests.
* Treat the separate translation endpoint as its own service boundary; do not infer that it is unavailable only because the main Project Lumen API is down. It may receive a parallel gate later if needed.

## Stability choices

* Avoid rapid flicker: use a short bounded probe with retry/backoff and a recent last-known reachable TTL while checking.
* Confirmed unreachable state hides/disables features; successful health refresh restores them automatically.
* Developer force-enable permits visibility/execution attempts but preserves the actual `unreachable` diagnostic state.
