# Gate Backend-Dependent Client Features When Unreachable

## Goal

Automatically hide and disable Project Lumen client features that depend on the backend when the backend cannot be reached, while keeping a developer-only manual override that can expose and exercise those features for diagnostics.

## What I already know

* The user requires all backend-communication-related functionality to close and hide automatically when the backend is unreachable.
* Settings pages must hide affected user-facing entries rather than leaving misleading controls visible.
* The Developer page must provide a manual enable/override for testing and recovery.
* The app already has backend API health/configuration, remote account/sync/backup/telemetry/update surfaces, and a Developer advanced page.
* Actual build, lint, and tests must run only through GitHub Actions.
* The solution must use a centralized policy rather than scattered per-screen connectivity checks or a super file.
* All main backend calls already converge through `ProjectLumenApiClient.request`, and `health()` provides a natural probe seam.
* Account/cloud operations are primarily exposed through `ProjectLumenRemoteFeatureEntry` and the Settings remote cloud card; telemetry and device-control calls also use the shared client.

## Assumptions

* “Backend” means the Project Lumen service configured by `ProjectLumenApiConfig`; the separately hosted translation service remains an independent availability boundary.
* Automatic gating should be based on a cached, bounded health result so a transient timeout does not cause rapid UI flicker.
* The developer override is explicit, persisted locally, visibly labeled, and does not pretend the backend is healthy; requests may still fail normally.
* Safety-critical local eye-care features remain available regardless of backend state.
* API-backed update checking is gated with the backend, while the external GitHub Releases link remains visible as an out-of-band recovery channel.

## Requirements (evolving)

* Define a central backend-availability state and a catalog/policy for backend-dependent capabilities.
* Probe backend reachability with timeout, retry/backoff, and cached state; avoid probing from every Composable.
* Hide affected Settings entries and disable non-UI execution paths when automatic gating is active.
* Add a Developer page override to force backend-dependent surfaces visible/enabled for diagnostics.
* Display actual health state and override state separately; never report a forced override as a successful health check.
* Preserve local-only features and data when backend features are gated.
* Add breadcrumbs/diagnostics without logging tokens, payloads, or other secrets.
* Persist the last known health result/time and developer override so the state remains stable across process restarts.
* Permit the health probe itself while communication is gated; all other main-backend calls must pass the centralized execution policy.

## Acceptance Criteria (evolving)

* [ ] Confirmed backend unreachability hides backend-dependent Settings entries and prevents their actions from executing.
* [ ] Account, cloud sync/backup, telemetry/upload, and other discovered Project Lumen backend consumers use the same capability policy.
* [ ] Local-only eye-care, device, and accessibility features remain available.
* [ ] Developer advanced page can force backend-dependent features visible/enabled and can return to automatic mode.
* [ ] UI distinguishes `reachable`, `unreachable`, `checking`, and `forced enabled` states without flicker loops.
* [ ] Recovery automatically restores normal visibility after a successful bounded health check.
* [ ] Pure policy/state tests and action-boundary regression tests run in GitHub Actions.
* [ ] The external GitHub Releases link remains usable when the Project Lumen API is gated.

## Definition of Done (team quality bar)

* Capability inventory and centralized policy are implemented without a super file.
* GitHub Actions build, lint, and tests pass.
* Trellis specs document reachability, override, recovery, and execution-boundary contracts.
* Source changes are committed without GPG signing and pushed automatically.

## Out of Scope (explicit)

* Disabling local-only app features because the network or backend is unavailable.
* Treating airplane mode or generic internet loss as proof that Project Lumen backend configuration is permanently invalid.
* Silently discarding queued user data without an explicit existing retention policy.
* Replacing the backend health endpoint or deployment architecture unless current code lacks a safe probe.

## Technical Notes

* Likely areas: `ProjectLumenApiClient`, API config/health routes, remote/account/sync/backup feature entries, telemetry reporters, update checks, Settings composition, ViewModel/state store, Developer debug screen, and MMKV/secure preference storage for override state.
* Source inspection will produce the authoritative capability inventory and determine whether release update discovery stays outside the automatic gate as a recovery path.

## Research References

* [`research/backend-capability-inventory.md`](research/backend-capability-inventory.md) — backend consumer inventory, shared API seam, developer override, recovery path, and translation-service boundary.

## Decision (ADR-lite)

**Context**: Hiding only Settings controls would leave background telemetry, device-control, and direct action paths active; probing from each screen would create duplicated state and flicker.

**Decision**: Add one application-scoped connectivity controller and pure effective-policy resolver. Gate every main-backend request except `health()` at the shared API boundary, consume the same state to hide Settings surfaces, expose actual health plus a separate persisted force-enable toggle in Developer advanced, and keep the external GitHub Releases link available.

**Consequences**: UI and background behavior stay consistent and recover automatically. The shared client gains a policy dependency, and the feature inventory must explicitly exclude independent third-party/translation endpoints unless they receive their own service health controller.
